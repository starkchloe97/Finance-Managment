<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphOne;

class LoanRepayment extends Model
{
    protected $fillable = ['loan_id', 'amount', 'payment_date', 'reference', 'notes', 'created_by'];

    protected $casts = ['amount' => 'decimal:2', 'payment_date' => 'date'];

    public function loan(): BelongsTo
    {
        return $this->belongsTo(Loan::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function receipt(): MorphOne
    {
        return $this->morphOne(TransactionReceipt::class, 'receiptable');
    }
}
