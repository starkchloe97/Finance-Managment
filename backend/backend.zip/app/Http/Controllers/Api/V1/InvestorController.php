<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\InvestorIndexRequest;
use App\Http\Requests\InvestorRequest;
use App\Http\Resources\InvestorResource;
use App\Models\Investor;
use App\Services\InvestorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class InvestorController extends Controller
{
    public function __construct(
        private InvestorService $investorService
    ) {}

    public function index(InvestorIndexRequest $request): AnonymousResourceCollection
    {
        $investors = $this->investorService->paginate($request->validated());

        return InvestorResource::collection($investors);
    }

    public function mine(Request $request): JsonResponse
    {
        return (new InvestorResource(
            $this->investorService->ensureOwnerProfile($request->user())
        ))->response()->setStatusCode(200);
    }

    public function store(InvestorRequest $request): InvestorResource
    {
        $investor = $this->investorService->create(
            $request->validated()
        );

        return new InvestorResource($investor);
    }

    public function show(Investor $investor): InvestorResource
    {
        return new InvestorResource($investor);
    }

    public function update(
        InvestorRequest $request,
        Investor $investor
    ): InvestorResource {
        $investor = $this->investorService->update(
            $investor,
            $request->validated()
        );

        return new InvestorResource($investor);
    }

    public function destroy(Investor $investor): JsonResponse
    {
        $this->investorService->delete($investor);

        return response()->json([
            'message' => 'Investor deleted successfully.',
        ]);
    }
}
