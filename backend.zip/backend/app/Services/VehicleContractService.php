<?php

namespace App\Services;

use App\Helpers\NumberGenerator;
use App\Models\VehicleContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class VehicleContractService
{
    public function __construct(private InvoiceService $invoices) {}

    public function paginate(array $filters = [])
    {
        $query = VehicleContract::query();

        if (! empty($filters['search'])) {
            $search = $filters['search'];

            $query->where(function ($q) use ($search) {
                $q->where(
                    'contract_number',
                    'like',
                    "%{$search}%"
                )->orWhere(
                    'vendor_name',
                    'like',
                    "%{$search}%"
                )->orWhere(
                    'customer_name',
                    'like',
                    "%{$search}%"
                )->orWhere(
                    'vehicle_make',
                    'like',
                    "%{$search}%"
                )->orWhere(
                    'vehicle_model',
                    'like',
                    "%{$search}%"
                );
            });
        }

        if (! empty($filters['status'])) {
            $query->where(
                'status',
                $filters['status']
            );
        }

        $query->with('vehicles');

        return $query
            ->latest()
            ->paginate(
                min(
                    max((int) ($filters['per_page'] ?? 10), 1),
                    100
                )
            );
    }

    public function create(array $data, ?int $userId = null): VehicleContract
    {
        return DB::transaction(function () use ($data, $userId) {

            $data['contract_number'] = NumberGenerator::generate(
                'CON',
                VehicleContract::class
            );

            $totalVehicles = max(
                (int) ($data['total_vehicles'] ?? count($data['vehicles'] ?? [])),
                1
            );

            $data['total_vehicles'] = $totalVehicles;
            $data['total_monthly_rental'] =
                $totalVehicles
                * (float) ($data['monthly_rental_per_vehicle'] ?? 0);

            $contract = VehicleContract::create($data);

            $this->createContractVehicles(
                $contract,
                $data
            );
            $this->invoices->createForVehicleContractMonth($contract, $userId);

            return $contract->load('vehicles');
        });
    }

    private function createContractVehicles(
        VehicleContract $contract,
        array $data
    ): void {
        $vehicles = $data['vehicles'] ?? [];

        foreach ($vehicles as $vehicle) {
            $contract->vehicles()->create([
                'vehicle_number' => $vehicle['vehicle_number'],

                'make' => $data['vehicle_make'],

                'model' => $data['vehicle_model'],

                'model_year' => $data['vehicle_model_year'],

                'vehicle_type' => $data['vehicle_type'],

                'monthly_rental' => $data['monthly_rental_per_vehicle'],

                'duty_hours_per_day' => $data['duty_hours_per_day'],

                'duty_days_per_week' => $data['duty_days_per_week'],

                'public_holiday_rate' => $data['public_holiday_rate'],

                'overtime_rate' => $data['overtime_rate'],

                'monthly_mileage_limit' => $data['monthly_mileage_limit'],

                'excess_mileage_rate' => $data['excess_mileage_rate'],

                'status' => 'active',
            ]);
        }
    }

    public function update(
        VehicleContract $contract,
        array $data,
        ?int $userId = null
    ): VehicleContract {
        $totalVehicles = max(
            (int) ($data['total_vehicles'] ?? $contract->total_vehicles ?? count($data['vehicles'] ?? [])),
            1
        );

        $data['total_vehicles'] = $totalVehicles;
        $data['total_monthly_rental'] =
            $totalVehicles
            * (float) ($data['monthly_rental_per_vehicle'] ?? $contract->monthly_rental_per_vehicle ?? 0);

        $contract->update($data);
        $this->invoices->createForVehicleContractMonth($contract, $userId);

        return $contract->refresh();
    }

    public function generateCurrentMonthPayables(): int
    {
        return $this->invoices->generateCurrentMonthVehicleContractPayables();
    }

    public function delete(VehicleContract $contract): void
    {
        if ($contract->invoices()->exists()) {
            throw ValidationException::withMessages([
                'contract' => 'A vehicle contract with linked payable invoices cannot be deleted.',
            ]);
        }

        $contract->delete();
    }
}
