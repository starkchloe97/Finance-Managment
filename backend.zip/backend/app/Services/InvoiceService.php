<?php

namespace App\Services;

use App\Enums\InvoiceDirection;
use App\Enums\PaymentDirection;
use App\Helpers\NumberGenerator;
use App\Models\BankAccount;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\InvoicePayment;
use App\Models\Payment;
use App\Models\TransportJob;
use App\Models\TransportJobExpense;
use App\Models\VehicleContract;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class InvoiceService
{
    public function list(array $filters, ?string $direction = null): LengthAwarePaginator
    {
        $query = Invoice::query()
            ->with(['customer', 'transportJob', 'jobExpense.transportJob', 'vehicleContract', 'hiredVehicle.estimateItem.estimate.transportJob'])
            ->withSum('allocations as paid_amount_sum', 'amount');

        if ($direction) {
            $query->where('direction', $direction);
        }
        foreach (['category', 'customer_id'] as $field) {
            if (! empty($filters[$field])) {
                $query->where($field, $filters[$field]);
            }
        }
        if (! empty($filters['from'])) {
            $query->whereDate('invoice_date', '>=', $filters['from']);
        }
        if (! empty($filters['to'])) {
            $query->whereDate('invoice_date', '<=', $filters['to']);
        }
        if (! empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($group) use ($search) {
                $group->where('invoice_no', 'like', "%{$search}%")
                    ->orWhere('party_name', 'like', "%{$search}%")
                    ->orWhere('party_company', 'like', "%{$search}%");
            });
        }
        if (! empty($filters['party'])) {
            $query->where(function ($group) use ($filters) {
                $group->where('party_name', 'like', '%'.$filters['party'].'%')
                    ->orWhere('party_company', 'like', '%'.$filters['party'].'%');
            });
        }

        if (! empty($filters['status'])) {
            $allocated = '(select coalesce(sum(invoice_payments.amount), 0) from invoice_payments where invoice_payments.invoice_id = invoices.id)';
            $status = $filters['status'];
            if ($status === 'paid') {
                $query->whereRaw("$allocated >= invoices.total");
            } elseif ($status === 'partially_paid') {
                $query->whereRaw("$allocated > 0 and $allocated < invoices.total")
                    ->where(fn ($q) => $q->whereNull('due_date')->orWhereDate('due_date', '>=', today()));
            } elseif ($status === 'overdue') {
                $query->whereDate('due_date', '<', today())
                    ->whereRaw("$allocated < invoices.total");
            } elseif ($status === 'unpaid') {
                $query->whereRaw("$allocated = 0")
                    ->where(fn ($q) => $q->whereNull('due_date')->orWhereDate('due_date', '>=', today()));
            }
        }

        return $query->latest('invoice_date')
            ->paginate(min(max((int) ($filters['per_page'] ?? 15), 1), 100));
    }

    public function create(array $data, int $userId): Invoice
    {
        return DB::transaction(function () use ($data, $userId) {
            $customer = ! empty($data['customer_id']) ? Customer::findOrFail($data['customer_id']) : null;
            [$subtotal, $tax, $total, $lines] = $this->calculateTotals($data);

            $invoice = Invoice::create([
                'invoice_no' => NumberGenerator::generate(
                    $data['direction'] === InvoiceDirection::Receivable->value ? 'SI' : 'PI',
                    Invoice::class
                ),
                'direction' => $data['direction'],
                'category' => $data['category'],
                'customer_id' => $customer?->id,
                'party_name' => $customer?->name ?? $data['party_name'],
                'party_company' => $customer?->company ?? ($data['party_company'] ?? null),
                'party_contact' => $data['party_contact'] ?? null,
                'party_phone' => $customer?->phone ?? ($data['party_phone'] ?? null),
                'party_address' => $customer?->address ?? ($data['party_address'] ?? null),
                'party_tax_number' => $data['party_tax_number'] ?? ($data['party_ntn_no'] ?? null),
                'party_ntn_no' => $data['party_ntn_no'] ?? ($data['party_tax_number'] ?? null),
                'party_str_no' => $data['party_str_no'] ?? null,
                'company_name' => $data['company_name'] ?? config('invoice.company_name'),
                'company_phone' => $data['company_phone'] ?? config('invoice.company_phone'),
                'company_address' => $data['company_address'] ?? config('invoice.company_address'),
                'company_tax_number' => $data['company_tax_number'] ?? ($data['company_ntn_no'] ?? config('invoice.company_ntn_no')),
                'company_str_no' => $data['company_str_no'] ?? config('invoice.company_str_no'),
                'company_ntn_no' => $data['company_ntn_no'] ?? ($data['company_tax_number'] ?? config('invoice.company_ntn_no')),
                'company_stnt_no' => $data['company_stnt_no'] ?? config('invoice.company_stnt_no'),
                'company_bank_details' => $data['company_bank_details'] ?? config('invoice.company_bank_details'),
                'company_logo_url' => $data['company_logo_url'] ?? config('invoice.company_logo_url'),
                'invoice_date' => $data['invoice_date'],
                'due_date' => $data['due_date'] ?? null,
                'subtotal' => $subtotal,
                'tax_amount' => $tax,
                'tax_label' => $data['tax_label'] ?? null,
                'tax_number' => $data['tax_number'] ?? null,
                'total' => $total,
                'notes' => $data['notes'] ?? null,
                'created_by' => $userId,
            ]);

            foreach ($lines as $line) {
                $invoice->items()->create([
                    'description' => $line['description'],
                    'quantity' => $line['quantity'],
                    'unit' => $line['unit'] ?? null,
                    'unit_price' => $line['unit_price'],
                    'amount' => $line['amount'],
                    'details' => $line['details'] ?? null,
                ]);
            }

            return $this->loadInvoice($invoice);
        });
    }

    public function update(Invoice $invoice, array $data): Invoice
    {
        return DB::transaction(function () use ($invoice, $data) {
            $invoice = Invoice::query()->lockForUpdate()->findOrFail($invoice->id);
            if ($invoice->transport_job_id || $invoice->allocations()->exists()) {
                throw ValidationException::withMessages([
                    'invoice' => 'Invoices linked to a job or with payment history cannot be edited.',
                ]);
            }
            if (
                $data['direction'] !== $invoice->direction->value ||
                $data['category'] !== $invoice->category
            ) {
                throw ValidationException::withMessages([
                    'category' => 'Invoice direction and category cannot be changed.',
                ]);
            }

            $customer = ! empty($data['customer_id']) ? Customer::findOrFail($data['customer_id']) : null;
            [$subtotal, $tax, $total, $lines] = $this->calculateTotals($data);
            $invoice->update([
                'customer_id' => $customer?->id,
                'party_name' => $customer?->name ?? $data['party_name'],
                'party_company' => $customer?->company ?? ($data['party_company'] ?? null),
                'party_contact' => $data['party_contact'] ?? null,
                'party_phone' => $customer?->phone ?? ($data['party_phone'] ?? null),
                'party_address' => $customer?->address ?? ($data['party_address'] ?? null),
                'party_tax_number' => $data['party_tax_number'] ?? ($data['party_ntn_no'] ?? null),
                'party_ntn_no' => $data['party_ntn_no'] ?? ($data['party_tax_number'] ?? null),
                'party_str_no' => $data['party_str_no'] ?? null,
                'company_name' => $data['company_name'] ?? config('invoice.company_name'),
                'company_phone' => $data['company_phone'] ?? config('invoice.company_phone'),
                'company_address' => $data['company_address'] ?? config('invoice.company_address'),
                'company_tax_number' => $data['company_tax_number'] ?? ($data['company_ntn_no'] ?? config('invoice.company_ntn_no')),
                'company_str_no' => $data['company_str_no'] ?? config('invoice.company_str_no'),
                'company_ntn_no' => $data['company_ntn_no'] ?? ($data['company_tax_number'] ?? config('invoice.company_ntn_no')),
                'company_stnt_no' => $data['company_stnt_no'] ?? config('invoice.company_stnt_no'),
                'company_bank_details' => $data['company_bank_details'] ?? config('invoice.company_bank_details'),
                'company_logo_url' => $data['company_logo_url'] ?? config('invoice.company_logo_url'),
                'invoice_date' => $data['invoice_date'],
                'due_date' => $data['due_date'] ?? null,
                'subtotal' => $subtotal,
                'tax_amount' => $tax,
                'tax_label' => $data['tax_label'] ?? null,
                'tax_number' => $data['tax_number'] ?? null,
                'total' => $total,
                'notes' => $data['notes'] ?? null,
            ]);
            $invoice->items()->get()->each(fn ($item) => $item->delete());
            foreach ($lines as $line) {
                $invoice->items()->create([
                    'description' => $line['description'],
                    'quantity' => $line['quantity'],
                    'unit' => $line['unit'] ?? null,
                    'unit_price' => $line['unit_price'],
                    'amount' => $line['amount'],
                    'details' => $line['details'] ?? null,
                ]);
            }

            return $this->loadInvoice($invoice);
        });
    }

    public function createForJob(TransportJob $job, int $userId): Invoice
    {
        return DB::transaction(function () use ($job, $userId) {
            $job = TransportJob::query()->with(['customer', 'estimate.items.vehicles.asset'])->lockForUpdate()->findOrFail($job->id);
            if ($job->status->value !== 'completed') {
                throw ValidationException::withMessages([
                    'job' => 'An invoice can only be generated for a completed job.',
                ]);
            }
            if (Invoice::where('transport_job_id', $job->id)->exists()) {
                throw ValidationException::withMessages([
                    'job' => 'An invoice has already been generated for this job.',
                ]);
            }
            if ((float) $job->sell_price <= 0) {
                throw ValidationException::withMessages([
                    'job' => 'A job with no sell price cannot be invoiced.',
                ]);
            }
            $customer = $job->customer;
            $estimate = $job->estimate;
            $truckNumbers = $estimate?->items
                ->flatMap(fn ($item) => $item->vehicles)
                ->map(fn ($vehicle) => $vehicle->registration_number ?? $vehicle->asset?->registration_number)
                ->filter()
                ->unique()
                ->implode(', ');
            $invoice = Invoice::create([
                'invoice_no' => NumberGenerator::generate('SI', Invoice::class),
                'direction' => InvoiceDirection::Receivable,
                'category' => 'job',
                'customer_id' => $customer?->id,
                'transport_job_id' => $job->id,
                'party_name' => $customer?->name ?? 'Customer',
                'party_company' => $customer?->company,
                'party_contact' => $customer?->company ? $customer->name : null,
                'party_phone' => $customer?->phone,
                'party_address' => $customer?->address,
                'company_name' => config('invoice.company_name'),
                'company_phone' => config('invoice.company_phone'),
                'company_address' => config('invoice.company_address'),
                'company_tax_number' => config('invoice.company_ntn_no'),
                'company_str_no' => config('invoice.company_str_no'),
                'company_ntn_no' => config('invoice.company_ntn_no'),
                'company_stnt_no' => config('invoice.company_stnt_no'),
                'company_bank_details' => config('invoice.company_bank_details'),
                'company_logo_url' => config('invoice.company_logo_url'),
                'invoice_date' => today(),
                'subtotal' => $job->sell_price,
                'tax_amount' => 0,
                'total' => $job->sell_price,
                'created_by' => $userId,
            ]);
            $invoice->items()->create([
                'description' => "Transport service for {$job->code}",
                'quantity' => 1,
                'unit' => 'job',
                'unit_price' => $job->sell_price,
                'amount' => $job->sell_price,
                'details' => [
                    'job_code' => $job->code,
                    'truck_no' => $truckNumbers ?: null,
                    'pickup' => $estimate?->pickup,
                    'drop' => $estimate?->destination,
                    'date' => $job->job_date?->toDateString(),
                    'type' => $estimate?->service_type,
                    'ton' => $estimate?->tonnage,
                ],
            ]);

            return $this->loadInvoice($invoice);
        });
    }

    public function createForJobExpense(TransportJobExpense $expense, ?int $userId = null): Invoice
    {
        return DB::transaction(function () use ($expense, $userId) {
            $expense = TransportJobExpense::query()
                ->with('transportJob')
                ->lockForUpdate()
                ->findOrFail($expense->id);

            $existing = Invoice::query()->where('job_expense_id', $expense->id)->first();
            if ($existing) {
                return $this->loadInvoice($existing);
            }

            $amount = round((float) $expense->amount, 2);
            $invoice = Invoice::create([
                'invoice_no' => NumberGenerator::generate('PI', Invoice::class),
                'direction' => InvoiceDirection::Payable,
                'category' => 'supplier',
                'job_expense_id' => $expense->id,
                'party_name' => 'Job expense',
                'invoice_date' => $expense->expense_date,
                'due_date' => $expense->expense_date,
                'subtotal' => $amount,
                'tax_amount' => 0,
                'total' => $amount,
                'notes' => "Payable created from job {$expense->transportJob->code}.",
                'created_by' => $userId,
            ]);
            $invoice->items()->create([
                'description' => $expense->title,
                'quantity' => 1,
                'unit_price' => $amount,
                'amount' => $amount,
                'details' => [
                    'job_id' => $expense->transportJob->id,
                    'job_code' => $expense->transportJob->code,
                    'expense_id' => $expense->id,
                    'category' => $expense->category->value,
                ],
            ]);

            return $this->loadInvoice($invoice);
        });
    }

    public function syncJobExpensePayable(TransportJobExpense $expense): void
    {
        $invoice = Invoice::query()
            ->where('job_expense_id', $expense->id)
            ->lockForUpdate()
            ->first();
        if (! $invoice) {
            return;
        }

        $amount = round((float) $expense->amount, 2);
        if ($amount < (float) $invoice->allocations()->sum('amount')) {
            throw ValidationException::withMessages([
                'amount' => 'Expense amount cannot be less than the amount already paid.',
            ]);
        }

        $invoice->update([
            'invoice_date' => $expense->expense_date,
            'due_date' => $expense->expense_date,
            'subtotal' => $amount,
            'total' => $amount,
        ]);
        $invoice->items()->firstOrFail()->update([
            'description' => $expense->title,
            'unit_price' => $amount,
            'amount' => $amount,
            'details' => [
                'job_id' => $expense->transportJob->id,
                'job_code' => $expense->transportJob->code,
                'expense_id' => $expense->id,
                'category' => $expense->category->value,
            ],
        ]);
    }

    public function removeJobExpensePayable(TransportJobExpense $expense): void
    {
        $invoice = Invoice::query()
            ->where('job_expense_id', $expense->id)
            ->lockForUpdate()
            ->first();
        if (! $invoice) {
            return;
        }

        if ($invoice->allocations()->exists()) {
            throw ValidationException::withMessages([
                'expense' => 'An expense with recorded payable payments cannot be deleted.',
            ]);
        }

        $invoice->delete();
    }

    /**
     * Create one payable for each hired vehicle on a newly converted job.
     *
     * The estimate item cost_total is distributed across the vehicle
     * requirements on that line. Company-owned vehicles consume their share
     * but never produce a supplier payable. The unique invoice source key and
     * the existence check make this safe to retry without duplicating invoices.
     */
    public function createForJobHiredVehicles(TransportJob $job, ?int $userId = null): void
    {
        DB::transaction(function () use ($job, $userId) {
            $job = TransportJob::query()
                ->with(['estimate.items.vehicles'])
                ->lockForUpdate()
                ->findOrFail($job->id);

            foreach ($job->estimate?->items ?? collect() as $item) {
                $vehicles = $item->vehicles;
                $vehicleCount = $vehicles->count();

                if ($vehicleCount === 0) {
                    continue;
                }

                $lineTotal = round((float) $item->cost_total, 2);
                $allocated = 0.0;

                foreach ($vehicles->values() as $index => $vehicle) {
                    // Assign rounding remainder to the final vehicle so the
                    // allocated shares always add up to the estimate line total.
                    $amount = $index === $vehicleCount - 1
                        ? round($lineTotal - $allocated, 2)
                        : round($lineTotal / $vehicleCount, 2);
                    $allocated = round($allocated + $amount, 2);

                    if ($vehicle->source !== 'hired' || $amount <= 0) {
                        continue;
                    }

                    if (blank($vehicle->supplier_name)) {
                        throw ValidationException::withMessages([
                            'supplier_name' => 'A supplier name is required for every hired vehicle before the job can be created.',
                        ]);
                    }

                    $existing = Invoice::query()
                        ->where('estimate_item_vehicle_id', $vehicle->id)
                        ->first();

                    if ($existing) {
                        continue;
                    }

                    $vehicleLabel = collect([
                        $vehicle->vehicle_name,
                        trim(($vehicle->make ?? '').' '.($vehicle->model ?? '')),
                        $vehicle->registration_number,
                    ])->filter()->first() ?: 'Hired vehicle';

                    $invoiceDate = $job->job_date?->toDateString() ?? today()->toDateString();

                    $invoice = Invoice::create([
                        'invoice_no' => NumberGenerator::generate('PI', Invoice::class),
                        'direction' => InvoiceDirection::Payable,
                        'category' => 'supplier',
                        'estimate_item_vehicle_id' => $vehicle->id,
                        'party_name' => $vehicle->supplier_name,
                        'invoice_date' => $invoiceDate,
                        'due_date' => $invoiceDate,
                        'subtotal' => $amount,
                        'tax_amount' => 0,
                        'total' => $amount,
                        'notes' => "Hired vehicle payable for job {$job->code}.",
                        'created_by' => $userId,
                    ]);

                    $invoice->items()->create([
                        'description' => "Vehicle hire — {$vehicleLabel}",
                        'quantity' => 1,
                        'unit' => 'vehicle',
                        'unit_price' => $amount,
                        'amount' => $amount,
                        'details' => [
                            'job_id' => $job->id,
                            'job_code' => $job->code,
                            'estimate_id' => $job->estimate_id,
                            'estimate_item_id' => $item->id,
                            'estimate_item_vehicle_id' => $vehicle->id,
                            'supplier_name' => $vehicle->supplier_name,
                            'vehicle_name' => $vehicle->vehicle_name,
                            'registration_number' => $vehicle->registration_number,
                        ],
                    ]);
                }
            }
        });
    }

    public function createForVehicleContractMonth(VehicleContract $contract, ?int $userId = null): ?Invoice
    {
        return DB::transaction(function () use ($contract, $userId) {
            $contract = VehicleContract::query()->lockForUpdate()->findOrFail($contract->id);
            $today = today();
            if (
                $contract->status !== 'active'
                || $contract->agreement_date->isAfter($today)
                || $contract->end_date->isBefore($today)
                || (float) $contract->total_monthly_rental <= 0
            ) {
                return null;
            }

            $billingPeriod = $today->copy()->startOfMonth();
            $existing = Invoice::query()
                ->where('vehicle_contract_id', $contract->id)
                ->whereDate('billing_period', $billingPeriod)
                ->exists();
            if ($existing) {
                return null;
            }

            $invoiceDate = $contract->agreement_date->greaterThan($billingPeriod)
                ? $contract->agreement_date
                : $billingPeriod;
            $amount = round((float) $contract->total_monthly_rental, 2);
            $invoice = Invoice::create([
                'invoice_no' => NumberGenerator::generate('PI', Invoice::class),
                'direction' => InvoiceDirection::Payable,
                'category' => 'vehicle_rental',
                'vehicle_contract_id' => $contract->id,
                'billing_period' => $billingPeriod,
                'party_name' => $contract->vendor_name,
                'party_address' => $contract->vendor_address,
                'invoice_date' => $invoiceDate,
                'due_date' => $billingPeriod->copy()->endOfMonth(),
                'subtotal' => $amount,
                'tax_amount' => 0,
                'total' => $amount,
                'notes' => "Vehicle rental for {$billingPeriod->format('Y-m')} under contract {$contract->contract_number}.",
                'created_by' => $userId,
            ]);
            $invoice->items()->create([
                'description' => "Vehicle rental for {$billingPeriod->format('F Y')}",
                'quantity' => 1,
                'unit' => 'month',
                'unit_price' => $amount,
                'amount' => $amount,
                'details' => [
                    'contract_id' => $contract->id,
                    'contract_number' => $contract->contract_number,
                    'billing_period' => $billingPeriod->toDateString(),
                ],
            ]);

            return $this->loadInvoice($invoice);
        });
    }

    public function generateCurrentMonthVehicleContractPayables(?int $userId = null): int
    {
        $contracts = VehicleContract::query()
            ->where('status', 'active')
            ->whereDate('agreement_date', '<=', today())
            ->whereDate('end_date', '>=', today())
            ->where('total_monthly_rental', '>', 0)
            ->get();
        $created = 0;

        foreach ($contracts as $contract) {
            if ($this->createForVehicleContractMonth($contract, $userId)) {
                $created++;
            }
        }

        return $created;
    }

    public function show(Invoice $invoice): Invoice
    {
        return $this->loadInvoice($invoice);
    }

    public function recordPayment(array $data, int $userId): Payment
    {
        return DB::transaction(function () use ($data, $userId) {
            $allocations = collect($data['allocations'])->sortBy('invoice_id')->values();
            $allocationTotal = round($allocations->sum(fn ($allocation) => (float) $allocation['amount']), 2);
            $paymentAmount = round((float) $data['amount'], 2);
            if ($allocationTotal !== $paymentAmount) {
                throw ValidationException::withMessages([
                    'amount' => 'Payment amount must equal the sum allocated to invoices.',
                ]);
            }

            $bankAccount = BankAccount::query()
                ->lockForUpdate()
                ->findOrFail($data['bank_account_id']);

            $invoices = Invoice::query()
                ->whereIn('id', $allocations->pluck('invoice_id'))
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');
            if ($invoices->count() !== $allocations->count()) {
                throw ValidationException::withMessages(['allocations' => 'One or more invoices no longer exist.']);
            }

            foreach ($allocations as $allocation) {
                /** @var Invoice $invoice */
                $invoice = $invoices->get($allocation['invoice_id']);
                $expectedDirection = $invoice->direction === InvoiceDirection::Receivable
                    ? PaymentDirection::Received->value
                    : PaymentDirection::Paid->value;
                if ($data['direction'] !== $expectedDirection) {
                    throw ValidationException::withMessages([
                        'direction' => 'Payment direction must match every allocated invoice.',
                    ]);
                }
                $outstanding = round((float) $invoice->total - (float) $invoice->allocations()->sum('amount'), 2);
                if ((float) $allocation['amount'] > $outstanding) {
                    throw ValidationException::withMessages([
                        'allocations' => "Allocation exceeds the outstanding amount for {$invoice->invoice_no}.",
                    ]);
                }
            }

            $currentBalance = round((float) $bankAccount->current_balance, 2);
            $balanceAfter = $data['direction'] === PaymentDirection::Received->value
                ? round($currentBalance + $paymentAmount, 2)
                : round($currentBalance - $paymentAmount, 2);
            if ($balanceAfter < 0) {
                throw ValidationException::withMessages([
                    'bank_account_id' => 'This bank account does not have enough funds for the payment.',
                ]);
            }
            if ($balanceAfter > 9999999999999.99) {
                throw ValidationException::withMessages([
                    'bank_account_id' => 'This transaction would exceed the maximum bank account balance.',
                ]);
            }

            $payment = Payment::create([
                'payment_no' => NumberGenerator::generate('PAY', Payment::class),
                'bank_account_id' => $bankAccount->id,
                'direction' => $data['direction'],
                'payment_date' => $data['payment_date'],
                'amount' => $paymentAmount,
                'payment_method' => $data['payment_method'] ?? null,
                'reference' => $data['reference'] ?? null,
                'notes' => $data['notes'] ?? null,
                'created_by' => $userId,
            ]);

            foreach ($allocations as $allocation) {
                InvoicePayment::create([
                    'invoice_id' => $allocation['invoice_id'],
                    'payment_id' => $payment->id,
                    'amount' => round((float) $allocation['amount'], 2),
                ]);
            }

            $bankAccount->update(['current_balance' => $balanceAfter]);
            $bankAccount->transactions()->create([
                'payment_id' => $payment->id,
                'type' => $data['direction'] === PaymentDirection::Received->value ? 'receipt' : 'payment',
                'amount' => $paymentAmount,
                'balance_after' => $balanceAfter,
                'description' => $payment->payment_no,
                'transaction_date' => $data['payment_date'],
            ]);

            return $payment->load(['bankAccount', 'allocations.invoice']);
        });
    }

    public function paymentList(): LengthAwarePaginator
    {
        return Payment::with(['bankAccount', 'allocations.invoice'])->latest('payment_date')->paginate(20);
    }

    public function dashboardSummary(): array
    {
        $paymentTotals = DB::table('invoice_payments')
            ->select('invoice_id')
            ->selectRaw('coalesce(sum(amount), 0) as paid')
            ->groupBy('invoice_id');

        $balances = DB::table('invoices')
            ->leftJoinSub($paymentTotals, 'payment_totals', function ($join) {
                $join->on('payment_totals.invoice_id', '=', 'invoices.id');
            })
            ->selectRaw('invoices.direction, invoices.category, invoices.due_date, invoices.total, coalesce(payment_totals.paid, 0) as paid');

        $rows = DB::query()->fromSub($balances, 'invoice_balances')
            ->selectRaw("
                coalesce(sum(case when direction = 'receivable' and total > paid then total - paid else 0 end), 0) as receivables,
                coalesce(sum(case when direction = 'payable' and total > paid then total - paid else 0 end), 0) as payables,
                coalesce(sum(case when direction = 'receivable' and due_date < ? and total > paid then total - paid else 0 end), 0) as overdue_receivables,
                coalesce(sum(case when direction = 'payable' and due_date < ? and total > paid then total - paid else 0 end), 0) as overdue_payables,
                coalesce(sum(case when direction = 'receivable' and category = 'commission' and total > paid then total - paid else 0 end), 0) as commission_receivable
            ", [today()->toDateString(), today()->toDateString()])
            ->first();

        return [
            'receivables' => (float) $rows->receivables,
            'payables' => (float) $rows->payables,
            'overdue_receivables' => (float) $rows->overdue_receivables,
            'overdue_payables' => (float) $rows->overdue_payables,
            'commission_receivable' => (float) $rows->commission_receivable,
        ];
    }

    private function loadInvoice(Invoice $invoice): Invoice
    {
        return $invoice->load([
            'customer', 'transportJob', 'items',
            'jobExpense.transportJob', 'vehicleContract',
            'hiredVehicle.estimateItem.estimate.transportJob',
            'allocations.payment.bankAccount', 'allocations.invoice',
        ])->loadSum('allocations as paid_amount_sum', 'amount');
    }

    private function calculateTotals(array $data): array
    {
        $subtotal = 0.0;
        $lines = [];
        foreach ($data['items'] as $item) {
            $amount = round((float) $item['quantity'] * (float) $item['unit_price'], 2);
            $subtotal = round($subtotal + $amount, 2);
            $item['amount'] = $amount;
            $lines[] = $item;
        }
        $tax = round((float) ($data['tax_amount'] ?? 0), 2);
        $total = round($subtotal + $tax, 2);
        if ($total <= 0) {
            throw ValidationException::withMessages([
                'items' => 'Invoice total must be greater than zero.',
            ]);
        }
        if ($total > 9999999999999.99 || collect($lines)->contains(fn ($line) => $line['amount'] > 9999999999999.99)) {
            throw ValidationException::withMessages([
                'items' => 'Invoice amounts exceed the maximum supported value.',
            ]);
        }

        return [$subtotal, $tax, $total, $lines];
    }
}
