<?php

namespace App\Http\Requests;

use App\Enums\AssetStatus;
use App\Enums\AssetType;
use App\Models\Asset;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AssetRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $asset = $this->route('asset');

        $assetId = $asset instanceof Asset
            ? $asset->id
            : null;

        return [
            /*
             * General
             */
            'asset_type' => [
                'required',
                Rule::enum(AssetType::class),
            ],

            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'description' => [
                'nullable',
                'string',
                'max:5000',
            ],

            /*
             * Vehicle
             */
            'make' => [
                'nullable',
                'string',
                'max:100',
            ],

            'model' => [
                'nullable',
                'string',
                'max:100',
            ],

            'model_year' => [
                'nullable',
                'integer',
                'min:1900',
                'max:'.(date('Y') + 1),
            ],

            'registration_number' => [
                'nullable',
                'string',
                'max:100',
                Rule::unique('assets', 'registration_number')
                    ->ignore($assetId),
            ],

            'vin' => [
                'nullable',
                'string',
                'max:100',
                Rule::unique('assets', 'vin')
                    ->ignore($assetId),
            ],

            'engine_number' => [
                'nullable',
                'string',
                'max:100',
                Rule::unique('assets', 'engine_number')
                    ->ignore($assetId),
            ],

            'vehicle_type' => [
                'nullable',
                'string',
                'max:100',
            ],

            'color' => [
                'nullable',
                'string',
                'max:50',
            ],

            'assigned_to' => [
                'nullable',
                'string',
                'max:255',
            ],

            'location' => [
                'nullable',
                'string',
                'max:255',
            ],

            /*
             * Financial
             */
            'purchase_date' => [
                'nullable',
                'date',
            ],

            'purchase_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'current_value' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            /*
             * Status
             */
            'status' => [
                'required',
                Rule::enum(AssetStatus::class),
            ],

            /*
             * Notes
             */
            'notes' => [
                'nullable',
                'string',
                'max:5000',
            ],

            'remarks' => [
                'nullable',
                'string',
                'max:5000',
            ],
        ];
    }
}
