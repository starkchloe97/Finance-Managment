<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('company_capital_transactions', function (Blueprint $table) {
            $table->boolean('available')->default(true)->after('amount');
        });
    }

    public function down(): void
    {
        Schema::table('company_capital_transactions', function (Blueprint $table) {
            $table->dropColumn('available');
        });
    }
};
