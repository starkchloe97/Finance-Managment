import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/authStore'
import AppLayout from '@/layouts/AppLayout.vue'
import Login from '@/pages/Login.vue'
import Dashboard from '@/pages/Dashboard.vue'

const secure = (breadcrumb) => ({ requiresAuth: true, breadcrumb })

const routes = [
  { path: '/login', name: 'login', component: Login, meta: { guest: true } },
  {
    path: '/',
    component: AppLayout,
    meta: secure('Dashboard'),
    children: [
      { path: '', name: 'dashboard', component: Dashboard, meta: secure('Dashboard') },
      { path: 'activities', name: 'activities.index', component: () => import('@/pages/Activity.vue'), meta: secure('Activity') },
      { path: 'queries', name: 'queries.index', component: () => import('@/pages/queries/QueriesList.vue'), meta: secure('Operations / Queries') },
      { path: 'queries/create', name: 'queries.create', component: () => import('@/pages/queries/QueryCreate.vue'), meta: secure('Operations / Queries / New query') },
      { path: 'queries/:id', name: 'queries.show', component: () => import('@/pages/queries/QueryShow.vue'), meta: secure('Operations / Queries / Details') },
      { path: 'invoices', name: 'invoices.index', component: () => import('@/pages/invoices/Invoices.vue'), meta: secure('Finance / Invoices') },
      { path: 'invoices/create', name: 'invoices.create', component: () => import('@/pages/invoices/InvoiceCreate.vue'), meta: secure('Finance / Invoices / Create') },
      { path: 'invoices/:id/edit', name: 'invoices.edit', component: () => import('@/pages/invoices/InvoiceCreate.vue'), meta: secure('Finance / Invoices / Edit') },
      { path: 'invoices/:id', name: 'invoices.show', component: () => import('@/pages/invoices/InvoiceShow.vue'), meta: secure('Finance / Invoices / Details') },
      { path: 'receivables', name: 'receivables.index', component: () => import('@/pages/invoices/Invoices.vue'), meta: secure('Finance / Receivables') },
      { path: 'payables', name: 'payables.index', component: () => import('@/pages/invoices/Invoices.vue'), meta: secure('Finance / Payables') },
      { path: 'commission-receivables', name: 'commission-receivables.index', component: () => import('@/pages/invoices/Invoices.vue'), meta: secure('Finance / Commission Receivable') },
      { path: 'payments', name: 'payments.index', component: () => import('@/pages/invoices/Payments.vue'), meta: secure('Finance / Payments') },
      { path: 'bank-accounts', name: 'bank-accounts.index', component: () => import('@/pages/BankAccounts.vue'), meta: secure('Finance / Bank accounts') },
      {
        path: 'customers',
        component: () => import('@/pages/customers/CustomersList.vue'),
        meta: secure('Operations / Customers'),
      },
      {
        path: 'customers/create',
        component: () => import('@/pages/customers/CustomerCreate.vue'),
        meta: secure('Operations / Customers / New customer'),
      },
      {
        path: 'customers/:id',
        component: () => import('@/pages/customers/CustomerDetail.vue'),
        meta: secure('Operations / Customers / Customer details'),
      },
      {
        path: 'customers/:id/edit',
        component: () => import('@/pages/customers/CustomerEdit.vue'),
        meta: secure('Operations / Customers / Edit customer'),
      },
      {
        path: 'estimates',
        component: () => import('@/pages/estimates/EstimatesList.vue'),
        meta: secure('Operations / Estimates'),
      },
      {
        path: 'estimates/create',
        component: () => import('@/pages/estimates/EstimateCreate.vue'),
        meta: secure('Operations / Estimates / New estimate'),
      },
      {
        path: 'estimates/:id',
        component: () => import('@/pages/estimates/EstimateDetail.vue'),
        meta: secure('Operations / Estimates / Estimate details'),
      },
      {
        path: 'estimates/:id/edit',
        component: () => import('@/pages/estimates/EstimateEdit.vue'),
        meta: secure('Operations / Estimates / Edit estimate'),
      },
      {
        path: 'jobs',
        component: () => import('@/pages/jobs/JobsList.vue'),
        meta: secure('Operations / Transport Jobs'),
      },
      {
        path: 'jobs/:id',
        component: () => import('@/pages/jobs/JobDetail.vue'),
        meta: secure('Operations / Transport Jobs / Job details'),
      },
      {
        path: 'investors',
        name: 'investors',
        component: () => import('@/pages/Investors/Investors.vue'),
        meta: secure('Finance / Investors'),
      },
      {
        path: 'investors/create',
        name: 'investor-create',
        component: () => import('@/pages/Investors/InvestorCreate.vue'),
        meta: secure('Finance / Investors / New investor'),
      },
      {
        path: 'investors/:id',
        name: 'investor-show',
        component: () => import('@/pages/Investors/InvestorShow.vue'),
        meta: secure('Finance / Investors / Investor details'),
      },
      {
        path: 'investors/:id/edit',
        name: 'investor-edit',
        component: () => import('@/pages/Investors/InvestorEdit.vue'),
        meta: secure('Finance / Investors / Edit investor'),
      },
      {
        path: 'loans',
        name: 'loans.index',
        component: () => import('@/pages/loans/LoansList.vue'),
        meta: secure('Finance / Loans'),
      },
      {
        path: 'loans/create',
        name: 'loans.create',
        component: () => import('@/pages/loans/LoanCreate.vue'),
        meta: secure('Finance / Loans / Issue loan'),
      },
      {
        path: 'loans/:id',
        name: 'loans.show',
        component: () => import('@/pages/loans/LoanShow.vue'),
        meta: secure('Finance / Loans / Loan details'),
      },
      {
        path: 'investments',
        name: 'investments.index',
        component: () => import('@/pages/investments/Investments.vue'),
        meta: secure('Finance / Investments'),
      },
      {
        path: 'investments/create',
        name: 'investments.create',
        component: () => import('@/pages/investments/InvestmentCreate.vue'),
        meta: secure('Finance / Investments / New investment'),
      },
      {
        path: 'investments/:id',
        name: 'investments.show',
        component: () => import('@/pages/investments/InvestmentShow.vue'),
        meta: secure('Finance / Investments / Investment details'),
      },
      {
        path: 'investments/:id/edit',
        name: 'investments.edit',
        component: () => import('@/pages/investments/InvestmentEdit.vue'),
        meta: secure('Finance / Investments / Edit investment'),
      },
      {
        path: 'assets',
        name: 'assets.index',
        component: () =>
          import('@/pages/assets/Assets.vue'),
        meta: secure('Operations / Assets'),
      },

      {
        path: 'assets/create',
        name: 'assets.create',
        component: () =>
          import('@/pages/assets/AssetCreate.vue'),
        meta: secure(
          'Operations / Assets / New vehicle'
        ),
      },

      {
        path: 'assets/:id',
        name: 'assets.show',
        component: () =>
          import('@/pages/assets/AssetShow.vue'),
        meta: secure(
          'Operations / Assets / Vehicle details'
        ),
      },

      {
        path: 'assets/:id/edit',
        name: 'assets.edit',
        component: () =>
          import('@/pages/assets/AssetEdit.vue'),
        meta: secure(
          'Operations / Assets / Edit vehicle'
        ),
      },
      {
        path: 'vehicle-contracts',
        name: 'vehicle-contracts.index',
        component: () =>
          import('@/pages/vehicle-contracts/VehicleContractsList.vue'),
        meta: secure('Operations / Vehicle Contracts'),
      },

      {
        path: 'vehicle-contracts/create',
        name: 'vehicle-contracts.create',
        component: () =>
          import('@/pages/vehicle-contracts/VehicleContractCreate.vue'),
        meta: secure(
          'Operations / Vehicle Contracts / New contract'
        ),
      },

      {
        path: 'vehicle-contracts/:id',
        name: 'vehicle-contracts.show',
        component: () =>
          import('@/pages/vehicle-contracts/VehicleContractShow.vue'),
        meta: secure(
          'Operations / Vehicle Contracts / Contract details'
        ),
      },

      {
        path: 'vehicle-contracts/:id/edit',
        name: 'vehicle-contracts.edit',
        component: () =>
          import('@/pages/vehicle-contracts/VehicleContractEdit.vue'),
        meta: secure(
          'Operations / Vehicle Contracts / Edit contract'
        ),
      },

      {
        path: 'on-road-vehicles',
        name: 'on-road-vehicles.index',
        component: () =>
          import(
            '@/pages/vehicle-daily-reports/OnRoadVehicles.vue'
          ),
        meta: secure('Operations / On Road Vehicles'),
      },
      {
        path: 'vehicle-daily-reports',
        name: 'vehicle-daily-reports.index',
        component: () =>
          import(
            '@/pages/vehicle-daily-reports/VehicleDailyReportsIndex.vue'
          ),
        meta: secure('Operations / Vehicle Reporting'),
      },
      {
        path: 'contract-vehicles/:id/daily-reports',
        name: 'contract-vehicles.daily-reports',
        component: () =>
          import(
            '@/pages/vehicle-daily-reports/VehicleDailyReportsPage.vue'
          ),
        props: true,
        meta: secure(
          'Operations / Vehicle Reporting / Daily reports'
        ),
      },
      {
        path: 'contract-vehicles/:id/daily-reports/create',
        name: 'contract-vehicles.daily-reports.create',
        component: () =>
          import(
            '@/pages/vehicle-daily-reports/VehicleDailyReportCreate.vue'
          ),
        meta: secure(
          'Operations / Vehicle Reporting / Add report'
        ),
      },
      {
        path: 'contract-vehicles/:id/daily-reports/:reportId/edit',
        name: 'contract-vehicles.daily-reports.edit',
        component: () =>
          import(
            '@/pages/vehicle-daily-reports/VehicleDailyReportEdit.vue'
          ),
        meta: secure(
          'Operations / Vehicle Reporting / Edit report'
        ),
      },
    ],
  },
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach(async (to) => {
  const auth = useAuthStore()

  if (auth.token && !auth.user) await auth.getUser()
  if (to.meta.requiresAuth && !auth.isAuthenticated) return '/login'
  if (to.meta.guest && auth.isAuthenticated) return '/'
})

export default router
